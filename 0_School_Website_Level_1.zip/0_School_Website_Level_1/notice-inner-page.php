<?php include 'common/header.php'; ?>
<?php include 'common/navigation.php'; ?>
<?php include 'common/hero-section.php'; ?>


<div class="notice_page inner_layout wdth_container" id="notice_inner_page">
    <div class="container">
        <div class="card_col card_smaller">
            <div class="card_col_flx">
                <div class="card_img">
                    <img src="assets/images/events/a.jpg" alt="">
                </div>
                <div class="card_img_des">
                <div class="blog_date">
                        <div class="date_item">
                        <h6><i class="fa-solid fa-calendar mini_icons"></i>July 07, 2024</h6>
                        </div>
                    </div>
                    <h4>Inspiring Curiosity and critical in kids</h4>
                    Lorem ipsum dolor sit amet consectetur. Eget id quam vestibulum malesuada nam tincidunt. Morbi interdum dolor lacus molestie. Nulla ultricies felis ultrices in convallis. Cras nibh proin quis odio metus pretium at viverra eget. Sit habitant ullamcorper ornare sit duis eget sed massa diam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus quibusdam, magni dolores veniam nihil nulla non eveniet magnam itaque earum facere, quas similique tenetur minima, autem laborum eaque aliquid fugiat? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quo aperiam, sapiente ipsa eligendi incidunt dolorem. Atque dolorem aperiam ullam voluptates assumenda quis nam corrupti sed blanditiis, eius sapiente? Est, possimus?
                    Saepe repudiandae cupiditate odit illo perspiciatis porro fugit veritatis repellendus eos alias repellat quibusdam minus, ad provident, corrupti perferendis magnam aut aliquam ipsum voluptates consequuntur, officiis illum aspernatur! Labore, voluptates.
                    Doloribus ex laboriosam corporis maiores ipsa, ut culpa incidunt optio beatae velit alias illo expedita quas fugiat voluptatibus natus harum tempore minus necessitatibus laborum tempora debitis voluptate enim! Obcaecati, perferendis!
                    Vero voluptates magni id expedita quas quia dicta delectus magnam, temporibus, blanditiis explicabo. Deserunt atque, tempora aperiam minima voluptates totam ullam ipsum obcaecati impedit beatae a non voluptate illum debitis!
                    Accusantium sapiente adipisci saepe repellat, suscipit error consequuntur id deserunt beatae maxime praesentium, nostrum veritatis voluptatibus, quae vel iusto. Provident quos quas quidem rerum dolore, exercitationem dolorem commodi hic! A.
                 
                   
                </div>
            </div>
        </div>
    </div>
</div>




<?php include 'common/footer.php'; ?>