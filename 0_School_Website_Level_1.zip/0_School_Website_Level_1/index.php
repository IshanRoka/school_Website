<?php include 'common/header.php';?>
<?php include 'common/navigation.php';?>
<?php include 'common/home/landingpage.php';?>
<?php include 'common/home/services.php';?>
<?php include 'common/home/aboutus.php';?>
<?php include 'common/home/counter.php';?>
<?php include 'common/home/message.php';?>
<?php include 'common/home/enquiry.php';?>
<?php include 'common/home/gallery.php';?>
<?php include 'common/home/events-notice.php';?>
<?php include 'common/home/news-blog.php';?>


<!-- resoponsive image with srcset and sizes  for high quality in big scree and low quality in small screen  -->



<?php include 'common/footer.php';?>
<?php include 'common/mobile_offcanvas.php';?>