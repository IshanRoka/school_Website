<?php include 'common/header.php'; ?>
<?php include 'common/navigation.php'; ?>
<?php include 'common/hero-section.php'; ?>

<section class="service_section inner_layout wdth_container" id="service_page">
    <div class="container">
        <div class="col_card_wrapper">
            <div class="col_card_flx_wrapper">
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon icon1">
                                <img src="" alt="">
                            </div>
                            <h4>Hostel Facilities</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon">

                            </div>
                            <h4>Transportation</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon icon1">

                            </div>
                            <h4>Science Lab</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon icon1">

                            </div>
                            <h4>Library</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon icon1">

                            </div>
                            <h4>Library</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon icon1">

                            </div>
                            <h4>Library</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php include 'common/footer.php'; ?>