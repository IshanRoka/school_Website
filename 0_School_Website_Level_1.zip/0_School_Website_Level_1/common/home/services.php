<section class="service_section">
    <div class="container">
        <div class="col_card_wrapper">
            <div class="col_card_flx_wrapper">
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon icon1">
                            <i class="fa-solid fa-hotel"></i>
                            </div>
                            <h4>Hostel Facilities</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon">
                            <i class="fa-solid fa-bus"></i>
                            </div>
                            <h4>Transportation</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon icon1">
                            <i class="fa-solid fa-flask"></i>
                            </div>
                            <h4>Science Lab</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="col_card_wrap">
                    <div class="col_card_inside_wrap">
                        <div class="card_title">
                            <div class="card_icon icon1">
                            <i class="fa-solid fa-book"></i>
                            </div>
                            <h4>Library</h4>
                        </div>
                        <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                        <div class="read_more_btn">
                            <a class="transparent_btn" href="service-inner-page.php">Read More <span class="arrow"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>