<section class="section two_col_sec">
    <div class="container">
        <div class="two_col_wrapper">
            <div class="two_col_wrapper_flx">
                <div class="left_col_wrapepr">
                    <h5>About Our School</h5>
                    <h1>A Few Words About the University</h1>
                    <p>Lorem ipsum dolor sit amet consectetur. Nibh amet vel euismod suspendisse scelerisque at. Egestas semper gravida a sit. Nisi neque nibh dolor turpis vestibulum odio lacinia ac neque. Et turpis amet nibh lacus ipsum laoreet et. In tincidunt tortor risus tempus morbi pretium etiam dui.
                        Netus dolor donec habitasse massa gravida praesent nulla. Augue praesent lobortis id neque non non nibh.</p>

                       <p>Pharetra amet magna molestie nulla facilisis sed nisl ut congue. Commodo euismod id vulputate at tortor leo. Quis nisi sollicitudin potenti vel commodo varius.</p>
                    <div class="sec_button">
                        <a href="about-page.php"><button class="btn_btn btn_primary">Read More</button></a>
                    </div>
                </div>
                <div class="right_col_wrapper">
                    <div class="right_img_wrap">
                        <img src="assets/images/about-us/about.jpg" alt="">
                        <div class="experience_text">
                            <div class="exp_flx">
                                <h1>10+</h1>
                                <h5>Years of Experience</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>