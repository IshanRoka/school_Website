<section class="section two_col_sec" id="message_sec">
    <div class="container">
        <div class="two_col_wrapper">
            <div class="two_col_wrapper_flx">
            <div class="right_col_wrapper">
                    <div class="right_img_wrap">
                        <img src="assets/images/message/profile.jpg" alt="">
                       
                    </div>
                </div>
                <div class="left_col_wrapepr">
                    <h5>Message From Founder</h5>
                    <h1>Education’s purpose is to replace an empty mind.</h1>
                    <p>Lorem ipsum dolor sit amet consectetur. Id massa ac facilisis enim non. Faucibus laoreet imperdiet pharetra ut elit eget quam faucibus. Congue risus et pharetra dolor vel pulvinar. Libero magna ut non orci leo laoreet mauris. A lorem elit egestas fringilla leo scelerisque</p>
                    <div class="message_from">
                      <h4>Srijana Kumari Ghimire</h4>
                      <h5>Chairman</h5>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
</section>