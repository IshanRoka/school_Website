<section class="landing_page">
    <div class="landing_wrapper">
        <div class="wrapper_img">
            <img src="assets/images/banner/banner1.jpg" alt="">
            <div class="overlay_details">
                <div class="container">
                    <h1>Education is passport to a successful career Learn Anything</h1>
                    <p>Lorem ipsum dolor sit amet consecte. Cras elit tellus in et phasellus varius diam id morbi. Cras elit tellus in et </p>
                </div>
            </div>
        </div>

    </div>
</section>