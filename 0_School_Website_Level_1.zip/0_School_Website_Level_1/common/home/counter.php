<section class="overlay_section">
    <div class="bg-overlay-img" style="background-image: url('assets/images/background/enquiry.png');"> </div>
    <div class="gradient-overlay"></div>
    <div class="container">
        <div class="counter_flx">
            <div class="counter_wrap">
                <div class="experience_text">
                    <div class="exp_flx">
                        <h1>10+</h1>
                        <h5>Years of Experience</h5>
                    </div>
                </div>
            </div>
            <div class="counter_wrap">
                <div class="experience_text">
                    <div class="exp_flx">
                        <h1>50+</h1>
                        <h5>Professional Teacher</h5>
                    </div>
                </div>
            </div>
            <div class="counter_wrap">
                <div class="experience_text">
                    <div class="exp_flx">
                        <h1>15+</h1>
                        <h5>Awards Wining</h5>
                    </div>
                </div>
            </div>
            <div class="counter_wrap">
                <div class="experience_text">
                    <div class="exp_flx">
                        <h1>10+</h1>
                        <h5>Years of Experience</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>