<section class="overlay_section">
    <div class="bg-overlay-img" style="background-image: url('assets/images/background/enquiry.png');"> </div>
    <div class="gradient-overlay"></div>
    <div class="container">
        <div class="overlay_description">
            <h4>WE WELCOME YOU TO LEARN MORE ABOUT OUR ADMISSION PROCESS</h4>
            <h1>WE’RE ALWAYS HAPPY TO HEAR FROM YOU</h1>
            <div class="sec_button">
                <a href="enquiry.php"><button class="btn_btn btn_primary white_border">Enquiry Now</button></a>
            </div>
        </div>
    </div>
</section>