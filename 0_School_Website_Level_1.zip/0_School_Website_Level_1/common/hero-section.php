<section class="overlay_section" id="hero_section">
    <div class="bg-overlay-img" style="background-image: url('assets/images/background/enquiry.png');"> </div>
    <div class="gradient-overlay"></div>
    <div class="container">
  <div class="hero_title">
    <h1>Inner Pages</h1>
  </div>
    </div>
</section>