<?php include 'common/header.php'; ?>
<?php include 'common/navigation.php'; ?>
<?php include 'common/hero-section.php'; ?>


<div class="notice_page inner_layout wdth_container">
    <div class="container">
        <div class="card_col card_smaller">
            <div class="card_col_flx">
                <div class="card_img">
                    <img src="assets/images/events/a.jpg" alt="">
                </div>
                <div class="card_img_des">
                <div class="blog_date">
                        <div class="date_item">
                        <h6><i class="fa-solid fa-calendar mini_icons"></i>July 07, 2024</h6>
                        </div>
                    </div>
                    <h4>Inspiring Curiosity and critical in kids</h4>
                    Lorem ipsum dolor sit amet consectetur. Eget id quam vestibulum malesuada nam tincidunt. Morbi interdum dolor lacus molestie. Nulla ultricies felis ultrices in convallis. Cras nibh proin quis odio metus pretium at viverra eget. Sit habitant ullamcorper ornare sit duis eget sed massa diam.
                    <div class="sec_button">
                    <button class="btn_btn btn_primary">Read More</button>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>




<?php include 'common/footer.php'; ?>